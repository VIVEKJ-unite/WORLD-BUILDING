List = ['Aman', 'Suraj', 'Aditya', 'Nikhil']
letter = "A"
result = [name for name in List if name.startswith(letter)]
print(result)
