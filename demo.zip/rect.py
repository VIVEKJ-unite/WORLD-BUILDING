L = float(input("enter the length of rectangle"))
B= float(input("enter the breadth of rectangle"))
area = L * B
perimeter = 2* (L + B)
print("area of rectangle is",round(area,3))
print("perimeter of rectangle is",round(perimeter,3))
